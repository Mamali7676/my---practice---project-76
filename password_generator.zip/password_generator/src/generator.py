import random
import string

def generate_password(length=12, use_symbols=True, use_numbers=True):
    """Generate a random password with given options."""
    letters = string.ascii_letters
    symbols = string.punctuation if use_symbols else ''
    numbers = string.digits if use_numbers else ''
    all_chars = letters + symbols + numbers

    if not all_chars:
        raise ValueError("No characters selected for password generation.")

    password = ''.join(random.choice(all_chars) for _ in range(length))
    return password