from generator import generate_password

def main():
    print("🔐 Password Generator 🔐")
    try:
        length = int(input("Enter password length (e.g. 12): "))
        use_symbols = input("Include symbols? (y/n): ").lower() == 'y'
        use_numbers = input("Include numbers? (y/n): ").lower() == 'y'

        password = generate_password(length, use_symbols, use_numbers)
        print(f"\n✅ Generated Password: {password}")

        save = input("Save to file? (y/n): ").lower()
        if save == 'y':
            with open("../data/example_passwords.txt", "a") as f:
                f.write(password + "\n")
            print("💾 Password saved in 'data/example_passwords.txt'")
    except Exception as e:
        print("❌ Error:", e)

if __name__ == "__main__":
    main()