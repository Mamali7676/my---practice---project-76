# 🔐 Password Generator

A simple random password generator built with **Python** on **iPhone** using the **Pyto** app.

---

## 📋 Description
This program creates strong random passwords using letters, numbers, and symbols.  
You can choose:
- The **length** of the password  
- Whether to include **symbols**  
- Whether to include **numbers**

The generated passwords can also be saved in a text file for later use.

---

## 📂 Project Structure
---
password_generator/
│
├── src/
│   ├── main.py           # Main script (run this file)
│   └── generator.py      # Password generation logic
│
├── data/
│   └── example_passwords.txt  # Saved passwords
│
├── tests/
│   └── test_generator.py      # Simple test script
│
├── README.md              # This file (project description)
└── requirements.txt       # Used Python
## 🚀 How to Run (in Pyto)
1. Open the **Pyto** app on your iPhone.  
2. Go to the folder `password_generator/src/`.  
3. Open the file `main.py`.  
4. Tap the **▶️ Run** button.  
5. Follow the on-screen prompts to generate your password.  

---

## 🧪 Testing
You can test the password generator by running:tests/test_generator.py

    
This will confirm that the password length works correctly.

---

## 💾 Example Output

🔐 Password Generator 🔐
Enter password length (e.g. 12): 10
Include symbols? (y/n): y
Include numbers? (y/n): y

✅ Generated Password: h%f2Lp#Dk9
💾 Password saved in ‘data/example_passwords.txt’

---

## 🧠 Made With
- Python 3 (via Pyto)
- Random & String modules
- iPhone 📱

---

## 🌟 Author
Created with ❤️ on mobile by a Python enthusiast using **Pyto**.


