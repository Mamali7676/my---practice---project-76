from generator import generate_password

def test_password():
    pw = generate_password(10)
    assert len(pw) == 10
    print("✅ Test passed: Password length is correct")

if __name__ == "__main__":
    test_password()